import { useEffect, useRef } from 'react'

interface Node {
  angle: number
  label: string
}

const nodes: Node[] = [
  { angle: 0, label: 'Emotion' },
  { angle: Math.PI / 4, label: 'Memory' },
  { angle: Math.PI / 2, label: 'Voice' },
  { angle: Math.PI * 0.75, label: 'Reasoning' },
  { angle: Math.PI, label: 'Decision' },
  { angle: Math.PI * 1.25, label: 'Workflow' },
  { angle: Math.PI * 1.5, label: 'Context' },
  { angle: Math.PI * 1.75, label: 'Learning' },
]

export default function RadialHub() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animRef = useRef<number>(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let w = 0
    let h = 0
    let cx = 0
    let cy = 0

    function resize() {
      const parent = canvas!.parentElement
      if (!parent) return
      w = canvas!.width = parent.offsetWidth
      h = canvas!.height = 400
      cx = w / 2
      cy = h / 2
    }

    function getNodePosition(node: Node) {
      const x = cx + Math.cos(node.angle) * 120
      const y = cy + Math.sin(node.angle) * 120
      return { x, y }
    }

    function drawArchitecture() {
      ctx!.clearRect(0, 0, w, h)

      const time = Date.now() * 0.001
      const pulse = 1 + Math.sin(time * 2) * 0.1
      const hub = { x: cx, y: cy }

      // Draw connection paths
      for (const node of nodes) {
        const pos = getNodePosition(node)
        const midX = (hub.x + pos.x) / 2
        const midY = (hub.y + pos.y) / 2 - 30
        ctx!.strokeStyle = 'rgba(212, 232, 52, 0.2)'
        ctx!.lineWidth = 1
        ctx!.beginPath()
        ctx!.moveTo(hub.x, hub.y)
        ctx!.quadraticCurveTo(midX, midY, pos.x, pos.y)
        ctx!.stroke()
      }

      // Draw traveling energy particles
      ctx!.fillStyle = '#D4E834'
      for (const node of nodes) {
        const pos = getNodePosition(node)
        const t = (time * 0.5 + node.angle / (Math.PI * 2)) % 1
        const startX = hub.x
        const startY = hub.y
        const endX = pos.x
        const endY = pos.y
        const cpx = (startX + endX) / 2
        const cpy = (startY + endY) / 2 - 30
        const px = (1 - t) * (1 - t) * startX + 2 * (1 - t) * t * cpx + t * t * endX
        const py = (1 - t) * (1 - t) * startY + 2 * (1 - t) * t * cpy + t * t * endY
        ctx!.beginPath()
        ctx!.arc(px, py, 3, 0, Math.PI * 2)
        ctx!.fill()
      }

      // Draw satellite nodes
      for (const node of nodes) {
        const pos = getNodePosition(node)
        ctx!.fillStyle = '#1A1A25'
        ctx!.strokeStyle = '#D4E834'
        ctx!.lineWidth = 2
        ctx!.beginPath()
        ctx!.arc(pos.x, pos.y, 20, 0, Math.PI * 2)
        ctx!.fill()
        ctx!.stroke()
        ctx!.fillStyle = '#F5F5F0'
        ctx!.font = '11px Inter, sans-serif'
        ctx!.textAlign = 'center'
        ctx!.fillText(node.label, pos.x, pos.y + 35)
      }

      // Draw central hub
      ctx!.shadowBlur = 20
      ctx!.shadowColor = 'rgba(212, 232, 52, 0.5)'
      ctx!.fillStyle = '#D4E834'
      ctx!.beginPath()
      ctx!.arc(cx, cy, 25 * pulse, 0, Math.PI * 2)
      ctx!.fill()
      ctx!.shadowBlur = 0
      ctx!.fillStyle = '#0A0A0F'
      ctx!.font = 'bold 12px "Space Grotesk", sans-serif'
      ctx!.textAlign = 'center'
      ctx!.textBaseline = 'middle'
      ctx!.fillText('CORE', cx, cy)
      ctx!.textBaseline = 'alphabetic'

      animRef.current = requestAnimationFrame(drawArchitecture)
    }

    resize()
    window.addEventListener('resize', resize)
    animRef.current = requestAnimationFrame(drawArchitecture)

    return () => {
      window.removeEventListener('resize', resize)
      cancelAnimationFrame(animRef.current)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{
        width: '100%',
        height: '400px',
      }}
    />
  )
}
