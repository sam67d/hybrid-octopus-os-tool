import { useEffect, useRef } from 'react'

interface Node {
  x: number
  y: number
  baseX: number
  baseY: number
  vx: number
  vy: number
  radius: number
  pulsePhase: number
  pulseSpeed: number
  brightness: number
  connections: number[]
}

interface Particle {
  from: number
  to: number
  progress: number
  speed: number
  hue: number
}

export default function NeuralBrainCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animRef = useRef<number>(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let w = 0
    let h = 0
    const nodes: Node[] = []
    const particles: Particle[] = []

    // Brain-shaped node distribution (roughly hemispheres)
    function generateBrainNodes() {
      nodes.length = 0
      particles.length = 0

      const cx = w / 2
      const cy = h / 2
      const scale = Math.min(w, h) * 0.38

      // Left hemisphere nodes
      const leftRegions = [
        { angleStart: -Math.PI * 0.85, angleEnd: -Math.PI * 0.15, rMin: 0.3, rMax: 1.0, count: 18 },
        { angleStart: -Math.PI * 0.7, angleEnd: -Math.PI * 0.3, rMin: 0.15, rMax: 0.55, count: 10 },
      ]

      // Right hemisphere nodes
      const rightRegions = [
        { angleStart: Math.PI * 0.15, angleEnd: Math.PI * 0.85, rMin: 0.3, rMax: 1.0, count: 18 },
        { angleStart: Math.PI * 0.3, angleEnd: Math.PI * 0.7, rMin: 0.15, rMax: 0.55, count: 10 },
      ]

      // Central bridge / corpus callosum
      const bridgeNodes = [
        { x: cx - scale * 0.08, y: cy - scale * 0.35 },
        { x: cx + scale * 0.08, y: cy - scale * 0.35 },
        { x: cx - scale * 0.06, y: cy - scale * 0.15 },
        { x: cx + scale * 0.06, y: cy - scale * 0.15 },
        { x: cx - scale * 0.05, y: cy + scale * 0.05 },
        { x: cx + scale * 0.05, y: cy + scale * 0.05 },
        { x: cx - scale * 0.07, y: cy + scale * 0.25 },
        { x: cx + scale * 0.07, y: cy + scale * 0.25 },
        { x: cx, y: cy - scale * 0.45 },
        { x: cx, y: cy + scale * 0.38 },
      ]

      const allNodePositions: { x: number; y: number }[] = []

      // Generate left hemisphere
      for (const region of leftRegions) {
        for (let i = 0; i < region.count; i++) {
          const angle = region.angleStart + Math.random() * (region.angleEnd - region.angleStart)
          const r = (region.rMin + Math.random() * (region.rMax - region.rMin)) * scale
          allNodePositions.push({ x: cx + Math.cos(angle) * r, y: cy + Math.sin(angle) * r * 1.15 })
        }
      }

      // Generate right hemisphere
      for (const region of rightRegions) {
        for (let i = 0; i < region.count; i++) {
          const angle = region.angleStart + Math.random() * (region.angleEnd - region.angleStart)
          const r = (region.rMin + Math.random() * (region.rMax - region.rMin)) * scale
          allNodePositions.push({ x: cx + Math.cos(angle) * r, y: cy + Math.sin(angle) * r * 1.15 })
        }
      }

      // Add bridge nodes
      for (const bn of bridgeNodes) {
        allNodePositions.push(bn)
      }

      // Create node objects
      for (let i = 0; i < allNodePositions.length; i++) {
        const pos = allNodePositions[i]
        const node: Node = {
          x: pos.x,
          y: pos.y,
          baseX: pos.x,
          baseY: pos.y,
          vx: 0,
          vy: 0,
          radius: 2 + Math.random() * 2.5,
          pulsePhase: Math.random() * Math.PI * 2,
          pulseSpeed: 0.3 + Math.random() * 0.5,
          brightness: 0.5 + Math.random() * 0.5,
          connections: [],
        }

        // Find nearby nodes for connections
        for (let j = 0; j < allNodePositions.length; j++) {
          if (i === j) continue
          const other = allNodePositions[j]
          const dx = pos.x - other.x
          const dy = pos.y - other.y
          const dist = Math.sqrt(dx * dx + dy * dy)
          if (dist < scale * 0.35 && node.connections.length < 5) {
            node.connections.push(j)
          }
        }

        nodes.push(node)
      }

      // Create traveling particles
      for (let i = 0; i < 12; i++) {
        const fromIdx = Math.floor(Math.random() * nodes.length)
        if (nodes[fromIdx].connections.length > 0) {
          const toIdx = nodes[fromIdx].connections[Math.floor(Math.random() * nodes[fromIdx].connections.length)]
          particles.push({
            from: fromIdx,
            to: toIdx,
            progress: Math.random(),
            speed: 0.003 + Math.random() * 0.005,
            hue: 160 + Math.random() * 40, // Cyan range
          })
        }
      }
    }

    function resize() {
      const parent = canvas!.parentElement
      if (!parent) return
      const rect = parent.getBoundingClientRect()
      w = canvas!.width = rect.width
      h = canvas!.height = rect.height
      generateBrainNodes()
    }

    function draw() {
      ctx!.clearRect(0, 0, w, h)

      const time = Date.now() * 0.001

      // Draw connection lines
      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i]
        for (const connIdx of node.connections) {
          if (connIdx <= i) continue // Avoid double-drawing
          const other = nodes[connIdx]

          const dx = node.x - other.x
          const dy = node.y - other.y
          const dist = Math.sqrt(dx * dx + dy * dy)
          const maxDist = Math.min(w, h) * 0.35
          const alpha = Math.max(0, 1 - dist / maxDist) * 0.25

          const grad = ctx!.createLinearGradient(node.x, node.y, other.x, other.y)
          grad.addColorStop(0, `rgba(52, 212, 232, ${alpha})`)
          grad.addColorStop(0.5, `rgba(212, 232, 52, ${alpha * 0.6})`)
          grad.addColorStop(1, `rgba(52, 212, 232, ${alpha})`)

          ctx!.strokeStyle = grad
          ctx!.lineWidth = 0.8
          ctx!.beginPath()
          ctx!.moveTo(node.x, node.y)
          ctx!.lineTo(other.x, other.y)
          ctx!.stroke()
        }
      }

      // Draw traveling particles
      for (const p of particles) {
        p.progress += p.speed
        if (p.progress >= 1) {
          p.progress = 0
          p.from = p.to
          const fromNode = nodes[p.from]
          if (fromNode.connections.length > 0) {
            p.to = fromNode.connections[Math.floor(Math.random() * fromNode.connections.length)]
          }
        }

        const fromNode = nodes[p.from]
        const toNode = nodes[p.to]
        const px = fromNode.x + (toNode.x - fromNode.x) * p.progress
        const py = fromNode.y + (toNode.y - fromNode.y) * p.progress

        ctx!.shadowBlur = 8
        ctx!.shadowColor = `hsla(${p.hue}, 80%, 60%, 0.8)`
        ctx!.fillStyle = `hsla(${p.hue}, 90%, 75%, 0.9)`
        ctx!.beginPath()
        ctx!.arc(px, py, 2.5, 0, Math.PI * 2)
        ctx!.fill()
        ctx!.shadowBlur = 0
      }

      // Draw nodes
      for (const node of nodes) {
        const pulse = 1 + Math.sin(time * node.pulseSpeed + node.pulsePhase) * 0.2
        const r = node.radius * pulse

        // Outer glow
        ctx!.shadowBlur = 12 * node.brightness
        ctx!.shadowColor = `rgba(52, 212, 232, ${0.4 * node.brightness})`

        // Node fill
        const nodeGrad = ctx!.createRadialGradient(node.x, node.y, 0, node.x, node.y, r * 2)
        nodeGrad.addColorStop(0, `rgba(212, 232, 52, ${node.brightness})`)
        nodeGrad.addColorStop(0.5, `rgba(52, 212, 232, ${node.brightness * 0.5})`)
        nodeGrad.addColorStop(1, 'rgba(52, 212, 232, 0)')

        ctx!.fillStyle = nodeGrad
        ctx!.beginPath()
        ctx!.arc(node.x, node.y, r * 2, 0, Math.PI * 2)
        ctx!.fill()

        // Core dot
        ctx!.fillStyle = `rgba(245, 245, 240, ${0.8 * node.brightness})`
        ctx!.beginPath()
        ctx!.arc(node.x, node.y, r * 0.5, 0, Math.PI * 2)
        ctx!.fill()

        ctx!.shadowBlur = 0
      }

      // Gentle ambient glow at center
      const ambientGrad = ctx!.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, Math.min(w, h) * 0.4)
      ambientGrad.addColorStop(0, 'rgba(52, 212, 232, 0.02)')
      ambientGrad.addColorStop(1, 'rgba(0, 0, 0, 0)')
      ctx!.fillStyle = ambientGrad
      ctx!.fillRect(0, 0, w, h)

      animRef.current = requestAnimationFrame(draw)
    }

    resize()
    window.addEventListener('resize', resize)
    animRef.current = requestAnimationFrame(draw)

    return () => {
      window.removeEventListener('resize', resize)
      cancelAnimationFrame(animRef.current)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{
        width: '100%',
        height: '100%',
        display: 'block',
      }}
    />
  )
}
