import { useEffect, useRef } from 'react'

interface EnergyPoint {
  x: number
  y: number
  speed: number
  angle: number
  ox: number
  oy: number
  trail: { x: number; y: number; alpha: number }[]
  hue: number
}

interface Props {
  hueBaseRef?: React.MutableRefObject<number>
  energyPointsRef?: React.MutableRefObject<EnergyPoint[]>
}

export default function NeuralEnergyCanvas({ hueBaseRef, energyPointsRef }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animRef = useRef<number>(0)
  const localHueRef = useRef(320)
  const localPointsRef = useRef<EnergyPoint[]>([])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const trailLength = 12
    const bloomStrength = 1.0
    let w = 0
    let h = 0
    let cx = 0
    let cy = 0

    const hueBase = hueBaseRef || localHueRef
    const energyPoints = energyPointsRef || localPointsRef

    function resize() {
      w = canvas!.width = window.innerWidth
      h = canvas!.height = window.innerHeight
      cx = w / 2
      cy = h / 2

      if (energyPoints.current.length === 0) {
        initEnergy()
      } else {
        energyPoints.current.forEach((p) => {
          p.ox = cx
          p.oy = cy
        })
      }
    }

    function initEnergy() {
      const points: EnergyPoint[] = []
      const baseHue = hueBase.current

      points.push(createPoint(cx, cy - 100, 0.8, 0, trailLength, baseHue))
      points.push(createPoint(cx, cy + 100, 0.8, Math.PI, trailLength, baseHue + 30))
      points.push(createPoint(cx - 100, cy, 0.6, Math.PI * 0.5, trailLength, baseHue - 30))
      points.push(createPoint(cx + 100, cy, 0.6, Math.PI * 1.5, trailLength, baseHue + 15))

      energyPoints.current = points
    }

    function createPoint(
      ox: number,
      oy: number,
      speed: number,
      angle: number,
      _tLen: number,
      hue: number
    ): EnergyPoint {
      return {
        x: ox,
        y: oy,
        speed,
        angle,
        ox,
        oy,
        trail: [],
        hue,
      }
    }

    function updatePoint(p: EnergyPoint) {
      p.angle += 0.02 * p.speed
      const r = 150 + Math.sin(p.angle * 3) * 80
      const tx = p.ox + Math.cos(p.angle) * r
      const ty = p.oy + Math.sin(p.angle * 2) * r * 0.6
      p.x += (tx - p.x) * 0.05
      p.y += (ty - p.y) * 0.05

      p.trail.unshift({ x: p.x, y: p.y, alpha: 1 })
      if (p.trail.length > trailLength) {
        p.trail.pop()
      }
      for (let i = 0; i < p.trail.length; i++) {
        p.trail[i].alpha *= 0.9
      }
    }

    function drawEnergy() {
      ctx!.fillStyle = 'rgba(10, 10, 15, 0.15)'
      ctx!.fillRect(0, 0, w, h)

      // Update points
      for (const p of energyPoints.current) {
        updatePoint(p)
      }

      // Draw bloom trails
      for (const p of energyPoints.current) {
        for (let j = 0; j < p.trail.length; j++) {
          const s = p.trail[j]
          if (s.alpha < 0.01) continue
          const bHue = (p.hue + j * 3) % 360
          ctx!.fillStyle = `hsla(${bHue}, 80%, 60%, ${s.alpha * 0.4 * bloomStrength})`
          ctx!.beginPath()
          ctx!.arc(s.x, s.y, (trailLength - j) * 0.8 + 2, 0, Math.PI * 2)
          ctx!.fill()
        }
      }

      // Draw connecting threads
      for (let i = 0; i < energyPoints.current.length; i++) {
        for (let j = i + 1; j < energyPoints.current.length; j++) {
          const p1 = energyPoints.current[i]
          const p2 = energyPoints.current[j]
          const dx = p1.x - p2.x
          const dy = p1.y - p2.y
          const dist = Math.sqrt(dx * dx + dy * dy)
          if (dist < 200) {
            const alpha = (1 - dist / 200) * 0.3 * bloomStrength
            const cHue = (p1.hue + p2.hue) * 0.5
            const grad = ctx!.createLinearGradient(p1.x, p1.y, p2.x, p2.y)
            grad.addColorStop(0, `hsla(${cHue}, 90%, 70%, 0)`)
            grad.addColorStop(0.2, `hsla(${cHue}, 90%, 70%, ${alpha})`)
            grad.addColorStop(0.8, `hsla(${cHue + 30}, 90%, 70%, ${alpha})`)
            grad.addColorStop(1, `hsla(${cHue + 30}, 90%, 70%, 0)`)
            ctx!.lineWidth = 1.5
            ctx!.strokeStyle = grad
            ctx!.beginPath()
            ctx!.moveTo(p1.x, p1.y)
            ctx!.lineTo(p2.x, p2.y)
            ctx!.stroke()
          }
        }
      }

      // Draw bright core dots
      for (const p of energyPoints.current) {
        ctx!.shadowBlur = 15
        ctx!.shadowColor = `hsla(${p.hue}, 100%, 70%, 1)`
        ctx!.fillStyle = `hsla(${p.hue}, 100%, 85%, 1)`
        ctx!.beginPath()
        ctx!.arc(p.x, p.y, 4, 0, Math.PI * 2)
        ctx!.fill()
        ctx!.shadowBlur = 0
      }

      animRef.current = requestAnimationFrame(drawEnergy)
    }

    resize()
    window.addEventListener('resize', resize)
    animRef.current = requestAnimationFrame(drawEnergy)

    return () => {
      window.removeEventListener('resize', resize)
      cancelAnimationFrame(animRef.current)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: 0,
        mixBlendMode: 'screen',
        opacity: 0.6,
        pointerEvents: 'none',
      }}
    />
  )
}
