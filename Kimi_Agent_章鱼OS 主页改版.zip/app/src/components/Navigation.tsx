import { useEffect, useRef, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const navLinks = [
  { label: 'Philosophy', href: '/about' },
  { label: 'Architecture', href: '/features' },
  { label: 'Ecosystem', href: '/technology' },
  { label: 'Mission', href: '/roadmap' },
  { label: 'Collaborate', href: '/contact' },
]

export default function Navigation() {
  const navRef = useRef<HTMLElement>(null)
  const [scrolled, setScrolled] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const nav = navRef.current
    if (!nav) return

    gsap.fromTo(
      nav,
      { y: -64, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', delay: 0.2 }
    )
  }, [])

  return (
    <nav
      ref={navRef}
      className="fixed top-0 left-0 w-full h-16 flex items-center justify-between px-6 lg:px-12 transition-all duration-300"
      style={{
        zIndex: 100,
        background: 'rgba(10, 10, 15, 0.85)',
        backdropFilter: 'blur(12px)',
        borderBottom: scrolled ? '1px solid rgba(245, 245, 240, 0.08)' : '1px solid transparent',
      }}
    >
      <Link
        to="/"
        className="font-display text-[#F5F5F0] text-base font-bold tracking-[3px] uppercase"
      >
        HYBRID OCTOPUS
      </Link>

      <div className="hidden md:flex items-center gap-8">
        {navLinks.map((link) => (
          <Link
            key={link.label}
            to={link.href}
            className="font-display text-sm text-[#F5F5F0] hover:text-[#D4E834] transition-colors duration-300"
            style={{
              color: location.pathname === link.href ? '#D4E834' : '#F5F5F0',
            }}
          >
            {link.label}
          </Link>
        ))}
      </div>

      <Link
        to="/contact"
        className="hidden md:block font-mono-accent text-xs uppercase tracking-[1.8px] px-6 py-2.5 border border-[#D4E834] text-[#D4E834] hover:bg-[#D4E834] hover:text-[#0A0A0F] transition-all duration-300"
      >
        Join the Mission
      </Link>

      {/* Mobile menu button */}
      <MobileMenu />
    </nav>
  )
}

function MobileMenu() {
  const [open, setOpen] = useState(false)

  return (
    <div className="md:hidden">
      <button
        onClick={() => setOpen(!open)}
        className="flex flex-col gap-1.5 p-2"
        aria-label="Toggle menu"
      >
        <span
          className="block w-5 h-px bg-[#F5F5F0] transition-transform duration-300"
          style={{
            transform: open ? 'rotate(45deg) translateY(4px)' : 'none',
          }}
        />
        <span
          className="block w-5 h-px bg-[#F5F5F0] transition-opacity duration-300"
          style={{ opacity: open ? 0 : 1 }}
        />
        <span
          className="block w-5 h-px bg-[#F5F5F0] transition-transform duration-300"
          style={{
            transform: open ? 'rotate(-45deg) translateY(-4px)' : 'none',
          }}
        />
      </button>

      {open && (
        <div
          className="absolute top-16 left-0 w-full py-6 px-6 flex flex-col gap-4"
          style={{ background: 'rgba(10, 10, 15, 0.95)', backdropFilter: 'blur(12px)' }}
        >
          {navLinks.map((link) => (
            <Link
              key={link.label}
              to={link.href}
              onClick={() => setOpen(false)}
              className="font-display text-sm text-[#F5F5F0] hover:text-[#D4E834] transition-colors"
            >
              {link.label}
            </Link>
          ))}
          <Link
            to="/contact"
            onClick={() => setOpen(false)}
            className="font-mono-accent text-xs uppercase tracking-[1.8px] px-6 py-2.5 border border-[#D4E834] text-[#D4E834] text-center mt-2"
          >
            Join the Mission
          </Link>
        </div>
      )}
    </div>
  )
}
