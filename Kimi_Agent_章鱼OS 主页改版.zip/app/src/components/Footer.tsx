import { useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const platformLinks = [
  { label: 'Philosophy', href: '/about' },
  { label: 'Architecture', href: '/features' },
  { label: 'Modules', href: '/features' },
  { label: 'Roadmap', href: '/roadmap' },
]

const communityLinks = [
  { label: 'Researchers', href: '/contact' },
  { label: 'Developers', href: '/contact' },
  { label: 'Partners', href: '/contact' },
  { label: 'Contributors', href: '/contact' },
]

const companyLinks = [
  { label: 'Mission', href: '/about' },
  { label: 'Vision', href: '/roadmap' },
  { label: 'Team', href: '/founder' },
  { label: 'Contact', href: '/contact' },
]

export default function Footer() {
  const footerRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const footer = footerRef.current
    if (!footer) return

    gsap.fromTo(
      footer.querySelectorAll('.footer-animate'),
      { y: 30, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 0.6,
        stagger: 0.1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: footer,
          start: 'top 90%',
        },
      }
    )
  }, [])

  return (
    <footer
      ref={footerRef}
      className="w-full pt-20 pb-10 px-6 lg:px-12"
      style={{ borderTop: '1px solid rgba(245, 245, 240, 0.08)', background: '#0A0A0F' }}
    >
      <div className="max-w-[1200px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          {/* Logo & Tagline */}
          <div className="footer-animate">
            <Link
              to="/"
              className="font-display text-base font-bold text-[#F5F5F0] tracking-[3px] uppercase block mb-3"
            >
              HYBRID OCTOPUS
            </Link>
            <p className="text-[13px] text-[#8A8A9A] leading-relaxed">
              A Human-Centric Living AI Ecosystem
            </p>
          </div>

          {/* Platform */}
          <div className="footer-animate">
            <h4 className="font-display text-sm text-[#F5F5F0] mb-4">Platform</h4>
            <ul className="space-y-2.5">
              {platformLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.href}
                    className="text-[13px] text-[#8A8A9A] hover:text-[#F5F5F0] transition-colors duration-300"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Community */}
          <div className="footer-animate">
            <h4 className="font-display text-sm text-[#F5F5F0] mb-4">Community</h4>
            <ul className="space-y-2.5">
              {communityLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.href}
                    className="text-[13px] text-[#8A8A9A] hover:text-[#F5F5F0] transition-colors duration-300"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div className="footer-animate">
            <h4 className="font-display text-sm text-[#F5F5F0] mb-4">Company</h4>
            <ul className="space-y-2.5">
              {companyLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.href}
                    className="text-[13px] text-[#8A8A9A] hover:text-[#F5F5F0] transition-colors duration-300"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>

            {/* Newsletter */}
            <div className="mt-8">
              <label className="font-mono-accent text-[11px] text-[#D4E834] uppercase tracking-[1.8px] block mb-3">
                Stay Updated
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="email"
                  placeholder="your@email.com"
                  className="flex-1 bg-transparent border-b border-[#8A8A9A] text-[#F5F5F0] text-sm py-1.5 outline-none focus:border-[#D4E834] transition-colors placeholder:text-[#3A3A4A]"
                />
                <button className="text-[#D4E834] text-lg hover:translate-x-1 transition-transform">
                  →
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="footer-animate flex flex-col md:flex-row items-center justify-between gap-4 pt-8 border-t border-[rgba(245,245,240,0.08)]">
          <p className="text-xs text-[#8A8A9A]">
            2025 Hybrid Octopus OS. All rights reserved.
          </p>
          <div className="flex items-center gap-5">
            {['GitHub', 'X', 'Discord', 'LinkedIn'].map((social) => (
              <a
                key={social}
                href="#"
                className="text-xs text-[#8A8A9A] hover:text-[#F5F5F0] transition-colors duration-300"
              >
                {social}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
