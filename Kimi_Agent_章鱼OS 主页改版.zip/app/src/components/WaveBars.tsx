import { useEffect, useRef } from 'react'

export default function WaveBars() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animRef = useRef<number>(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let w = 0
    let h = 0

    function resize() {
      const parent = canvas!.parentElement
      if (!parent) return
      w = canvas!.width = parent.offsetWidth
      h = canvas!.height = 250
    }

    function draw() {
      ctx!.clearRect(0, 0, w, h)

      const bars = 7
      const barWidth = 30
      const gap = (w - bars * barWidth) / (bars + 1)
      const time = Date.now() * 0.002

      for (let i = 0; i < bars; i++) {
        const x = gap + i * (barWidth + gap)
        const wave = Math.sin(time + i * 0.5) * 0.5 + 0.5
        const barHeight = 50 + wave * 150
        const y = h - barHeight

        const grad = ctx!.createLinearGradient(x, h, x, y)
        grad.addColorStop(0, '#D4E834')
        grad.addColorStop(1, '#E834D4')

        ctx!.fillStyle = grad
        ctx!.fillRect(x, y, barWidth, barHeight)
      }

      animRef.current = requestAnimationFrame(draw)
    }

    resize()
    window.addEventListener('resize', resize)
    animRef.current = requestAnimationFrame(draw)

    return () => {
      window.removeEventListener('resize', resize)
      cancelAnimationFrame(animRef.current)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{
        width: '100%',
        height: '250px',
      }}
    />
  )
}
