import { useEffect, useRef } from 'react'

export default function PerspectiveLines() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animRef = useRef<number>(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let w = 0
    let h = 0

    function resize() {
      const parent = canvas!.parentElement
      if (!parent) return
      w = canvas!.width = parent.offsetWidth
      h = canvas!.height = 300
    }

    function draw() {
      ctx!.clearRect(0, 0, w, h)

      const lines = 8
      const text = 'UNDERSTAND \u2022 ADAPT \u2022 EVOLVE \u2022 '
      const time = Date.now() * 0.0005

      for (let i = 0; i < lines; i++) {
        const y = h / 2 + (i - lines / 2) * 30
        const depth = Math.abs(i - lines / 2) / (lines / 2)
        const alpha = 1 - depth * 0.7
        const scale = 1 - depth * 0.3

        ctx!.font = `${16 * scale}px "Space Grotesk", sans-serif`

        let x: number
        if (i % 2 === 0) {
          x = (time * 50 * scale) % (w + 200) - 100
        } else {
          x = (-time * 50 * scale) % (w + 200) - 100
        }

        if (depth < 0.5) {
          ctx!.fillStyle = `rgba(245, 245, 240, ${alpha})`
        } else {
          ctx!.fillStyle = `rgba(58, 58, 74, ${alpha})`
        }

        let j = 0
        while (j * 200 < w + 400) {
          ctx!.fillText(text, x + j * 200 - 200, y)
          j++
        }
      }

      animRef.current = requestAnimationFrame(draw)
    }

    resize()
    window.addEventListener('resize', resize)
    animRef.current = requestAnimationFrame(draw)

    return () => {
      window.removeEventListener('resize', resize)
      cancelAnimationFrame(animRef.current)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{
        width: '100%',
        height: '300px',
      }}
    />
  )
}
