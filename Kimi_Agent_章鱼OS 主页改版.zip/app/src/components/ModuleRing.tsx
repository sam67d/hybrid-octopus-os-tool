import { useEffect, useRef } from 'react'
import gsap from 'gsap'

const modules = ['E', 'M', 'V', 'R', 'D', 'A', 'L', 'C', 'W', 'S', 'F', 'H']

export default function ModuleRing() {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const items = container.querySelectorAll<HTMLDivElement>('.module-item')
    const totalItems = items.length
    const radius = Math.min(container.offsetWidth, container.offsetHeight) * 0.35

    items.forEach((item, i) => {
      const angle = (i / totalItems) * Math.PI * 2
      gsap.set(item, {
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius,
        rotationX: 0,
        rotationY: i * (360 / totalItems),
      })
    })

    const tween = gsap.to(container, {
      rotationX: 360,
      rotationY: -360,
      duration: 20,
      ease: 'none',
      repeat: -1,
    })

    return () => { tween.kill() }
  }, [])

  return (
    <div
      ref={containerRef}
      className="module-ring-container"
      style={{
        width: '300px',
        height: '300px',
        position: 'relative',
        transformStyle: 'preserve-3d',
        perspective: '800px',
      }}
    >
      {modules.map((mod, i) => (
        <div
          key={i}
          className="module-item"
          style={{
            width: '40px',
            height: '40px',
            position: 'absolute',
            top: '50%',
            left: '50%',
            margin: '-20px 0 0 -20px',
            background: '#1A1A25',
            border: '1px solid #D4E834',
            color: '#D4E834',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: '12px',
            borderRadius: '4px',
          }}
        >
          {mod}
        </div>
      ))}
    </div>
  )
}
