import { useEffect, useRef } from 'react'

interface CursorParticle {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  decay: number
  hue: number
  size: number
}

export default function CursorParticles() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const particlesRef = useRef<CursorParticle[]>([])
  const animRef = useRef<number>(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0
    if (isTouchDevice) return

    const cursorParticleCount = 3
    const cursorSpread = 2.0
    const particleLife = 30
    const driftSpeed = 1.5
    const hueBase = 320
    const hueRange = 60

    let w = 0
    let h = 0

    function resize() {
      w = canvas!.width = window.innerWidth
      h = canvas!.height = window.innerHeight
    }

    function addCursorEnergy(x: number, y: number) {
      const angle = Math.random() * Math.PI * 2
      const speed = Math.random() * cursorSpread + 0.5
      const p: CursorParticle = {
        x: x + (Math.random() - 0.5) * 10,
        y: y + (Math.random() - 0.5) * 10,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 1.0,
        decay: 1 / (particleLife + Math.random() * 20),
        hue: (hueBase + Math.random() * hueRange) % 360,
        size: Math.random() * 2 + 1,
      }
      particlesRef.current.push(p)
      if (particlesRef.current.length > 100) {
        particlesRef.current = particlesRef.current.slice(-80)
      }
    }

    function drawCursorParticles() {
      ctx!.clearRect(0, 0, w, h)

      for (let i = particlesRef.current.length - 1; i >= 0; i--) {
        const p = particlesRef.current[i]
        p.life -= p.decay
        if (p.life <= 0) {
          particlesRef.current.splice(i, 1)
          continue
        }
        p.x += p.vx * driftSpeed
        p.y += p.vy * driftSpeed
        p.vx *= 0.98
        p.vy *= 0.98

        const alpha = p.life * 0.6
        ctx!.fillStyle = `hsla(${p.hue}, 80%, 70%, ${alpha})`
        ctx!.beginPath()
        ctx!.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2)
        ctx!.fill()
      }

      animRef.current = requestAnimationFrame(drawCursorParticles)
    }

    const onMouseMove = (e: MouseEvent) => {
      addCursorEnergy(e.clientX, e.clientY)
      for (let i = 0; i < cursorParticleCount - 1; i++) {
        addCursorEnergy(e.clientX, e.clientY)
      }
    }

    resize()
    window.addEventListener('resize', resize)
    window.addEventListener('mousemove', onMouseMove)
    animRef.current = requestAnimationFrame(drawCursorParticles)

    return () => {
      window.removeEventListener('resize', resize)
      window.removeEventListener('mousemove', onMouseMove)
      cancelAnimationFrame(animRef.current)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: 1,
        pointerEvents: 'none',
      }}
    />
  )
}
