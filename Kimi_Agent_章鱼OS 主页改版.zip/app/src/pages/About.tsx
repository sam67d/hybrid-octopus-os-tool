import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function About() {
  const pageRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    window.scrollTo(0, 0)
    const page = pageRef.current
    if (!page) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        page.querySelectorAll('.about-animate'),
        { y: 50, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.9, stagger: 0.15, ease: 'power3.out',
          scrollTrigger: { trigger: page, start: 'top 80%' },
        }
      )
    }, page)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={pageRef} className="pt-16">
      {/* Hero */}
      <section className="relative w-full py-[160px] px-6 lg:px-12 text-center" style={{ background: '#0A0A0F' }}>
        <div className="max-w-[900px] mx-auto">
          <span className="label-accent block mb-6 about-animate">ABOUT</span>
          <h1
            className="about-animate font-display font-bold text-[#F5F5F0] mb-8"
            style={{ fontSize: 'clamp(36px, 6vw, 64px)', letterSpacing: '-1.92px', lineHeight: 1.0 }}
          >
            A New Kind of Intelligence
          </h1>
          <p className="about-animate text-sm text-[#8A8A9A] leading-relaxed max-w-[600px] mx-auto">
            Hybrid Octopus OS is not an AI tool. It is a living, breathing digital ecosystem designed
            to think, feel, remember, and evolve — all in service of human potential.
          </p>
        </div>
      </section>

      {/* Mission */}
      <section className="relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#12121A' }}>
        <div className="max-w-[1200px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div>
            <span className="label-accent block mb-6 about-animate">OUR MISSION</span>
            <h2 className="about-animate font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-6">
              To Create Intelligence That Truly Understands
            </h2>
            <p className="about-animate text-sm text-[#8A8A9A] leading-relaxed mb-4">
              Most AI systems respond to inputs. Hybrid Octopus OS is designed to understand context,
              emotion, intent, and history — building a relationship with every user that deepens
              over time.
            </p>
            <p className="about-animate text-sm text-[#8A8A9A] leading-relaxed">
              We believe the next frontier of AI is not raw compute power, but emotional and
              contextual intelligence — the ability to meet humans where they are and grow alongside
              them.
            </p>
          </div>
          <div className="about-animate flex items-center justify-center">
            <div
              className="w-full max-w-[400px] aspect-square border border-[rgba(245,245,240,0.08)] flex items-center justify-center"
              style={{ background: 'rgba(26, 26, 37, 0.6)' }}
            >
              <div className="text-center">
                <div
                  className="w-32 h-32 mx-auto mb-6 rounded-full flex items-center justify-center"
                  style={{
                    background: 'radial-gradient(circle, rgba(212,232,52,0.2) 0%, transparent 70%)',
                    border: '1px solid rgba(212,232,52,0.3)',
                  }}
                >
                  <span className="font-display text-4xl text-[#D4E834] font-bold">16</span>
                </div>
                <p className="font-display text-lg text-[#F5F5F0]">Intelligence Modules</p>
                <p className="text-xs text-[#8A8A9A] mt-1">Unified in One Ecosystem</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Philosophy */}
      <section className="relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#0A0A0F' }}>
        <div className="max-w-[800px] mx-auto">
          <span className="label-accent block mb-6 about-animate">PHILOSOPHY</span>
          <h2 className="about-animate font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-8">
            Human-Centric by Design
          </h2>
          <div className="space-y-6">
            {[
              {
                title: 'Understanding Over Response',
                desc: 'We prioritize comprehension over speed. Every interaction is an opportunity to build deeper understanding of human needs, emotions, and goals.',
              },
              {
                title: 'Memory as Foundation',
                desc: 'Intelligence without memory is merely reaction. Our adaptive memory system creates persistent, contextual knowledge that grows richer with every interaction.',
              },
              {
                title: 'Emotion as Signal',
                desc: 'Emotions are not noise to be filtered — they are critical signals that inform better decisions, more natural interactions, and deeper connections.',
              },
              {
                title: 'Evolution Over Deployment',
                desc: 'Hybrid Octopus OS is never "finished." It is a continuously evolving system that learns, adapts, and improves through self-reflection and human feedback.',
              },
            ].map((item, i) => (
              <div key={i} className="about-animate border-l-2 border-[#D4E834] pl-6 py-2">
                <h3 className="font-display text-lg text-[#F5F5F0] mb-2">{item.title}</h3>
                <p className="text-sm text-[#8A8A9A] leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Human-AI Coexistence */}
      <section className="relative w-full py-[120px] px-6 lg:px-12 text-center" style={{ background: '#12121A' }}>
        <div className="max-w-[800px] mx-auto">
          <span className="label-accent block mb-6 about-animate">THE FUTURE</span>
          <h2 className="about-animate font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-6">
            Designed for Human-AI Coexistence
          </h2>
          <p className="about-animate text-sm text-[#8A8A9A] leading-relaxed mb-10">
            We believe the future of intelligence is not artificial replacing human — it's hybrid,
            collaborative, and deeply interwoven. Hybrid Octopus OS is built on the principle that
            technology should amplify human capability, not diminish it.
          </p>
          <blockquote className="about-animate border-t border-b border-[rgba(245,245,240,0.08)] py-8">
            <p className="font-display text-xl text-[#F5F5F0] italic leading-relaxed">
              "Most AI systems respond. Hybrid Octopus OS is being designed to understand."
            </p>
          </blockquote>
        </div>
      </section>
    </div>
  )
}
