import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function Founder() {
  const pageRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    window.scrollTo(0, 0)
    const page = pageRef.current
    if (!page) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        page.querySelectorAll('.founder-animate'),
        { y: 50, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.9, stagger: 0.15, ease: 'power3.out',
          scrollTrigger: { trigger: page, start: 'top 80%' },
        }
      )
    }, page)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={pageRef} className="pt-16">
      {/* Hero */}
      <section className="relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#0A0A0F' }}>
        <div className="max-w-[1200px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <span className="label-accent block mb-6">FOUNDER</span>
            <h1
              className="font-display font-bold text-[#F5F5F0] mb-6"
              style={{ fontSize: 'clamp(36px, 6vw, 64px)', letterSpacing: '-1.92px', lineHeight: 1.0 }}
            >
              The Mind Behind the Mission
            </h1>
            <p className="text-sm text-[#8A8A9A] leading-relaxed">
              A visionary founder driven by the belief that AI should amplify humanity, not replace
              it. The journey of building Hybrid Octopus OS began with a simple question: what if
              technology could truly understand us?
            </p>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative">
              <div
                className="w-[280px] h-[360px] lg:w-[340px] lg:h-[440px] overflow-hidden"
                style={{ border: '1px solid rgba(245, 245, 240, 0.08)' }}
              >
                <img
                  src="/founder-portrait.jpg"
                  alt="Founder"
                  className="w-full h-full object-cover"
                />
              </div>
              <div
                className="absolute -bottom-4 -right-4 w-24 h-24 border border-[#D4E834] flex items-center justify-center"
                style={{ background: 'rgba(10, 10, 15, 0.9)' }}
              >
                <span className="font-mono-accent text-xs text-[#D4E834] text-center uppercase tracking-wider">
                  Est<br />2024
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Origin */}
      <section className="relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#12121A' }}>
        <div className="max-w-[800px] mx-auto">
          <span className="label-accent block mb-6">THE ORIGIN</span>
          <h2 className="founder-animate font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-8">
            Born from a Frustration, Built for a Vision
          </h2>
          <div className="space-y-6">
            <p className="founder-animate text-sm text-[#8A8A9A] leading-relaxed">
              The idea for Hybrid Octopus OS emerged from years of working with AI systems that were
              brilliant in isolation yet fundamentally disconnected. Voice assistants that couldn't
              remember context. Recommendation engines that ignored emotion. Decision systems that
              operated as black boxes.
            </p>
            <p className="founder-animate text-sm text-[#8A8A9A] leading-relaxed">
              What if these fragmented capabilities could be unified into a single coherent
              intelligence? What if an AI system could not only process information but truly
              understand the human on the other side?
            </p>
            <p className="founder-animate text-sm text-[#8A8A9A] leading-relaxed">
              This question became the foundation of Hybrid Octopus OS — a project that started as
              a thought experiment and evolved into a mission to redefine the relationship between
              humans and artificial intelligence.
            </p>
          </div>
        </div>
      </section>

      {/* Core Beliefs */}
      <section className="relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#0A0A0F' }}>
        <div className="max-w-[1200px] mx-auto">
          <span className="label-accent block mb-6">CORE BELIEFS</span>
          <h2 className="founder-animate font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-12">
            Principles That Guide Us
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                num: '01',
                title: 'Intelligence Should Serve Humanity',
                desc: 'Technology exists to amplify human potential, not replace human judgment. Every feature we build is evaluated against this core principle.',
              },
              {
                num: '02',
                title: 'Understanding Is Greater Than Speed',
                desc: 'A slower response that truly understands context is more valuable than an instant answer that misses the point. Depth beats velocity.',
              },
              {
                num: '03',
                title: 'Trust Is Earned Through Transparency',
                desc: 'Users deserve to know how decisions are made. Explainability is not a feature — it is a requirement for any system that influences human lives.',
              },
              {
                num: '04',
                title: 'Evolution Is Continuous',
                desc: 'The best AI systems are never "finished." They learn, adapt, and grow alongside their users, becoming more valuable with every interaction.',
              },
            ].map((belief, i) => (
              <div
                key={i}
                className="founder-animate p-8 border border-[rgba(245,245,240,0.08)]"
                style={{ background: 'rgba(26, 26, 37, 0.6)' }}
              >
                <span className="font-mono-accent text-xs text-[#D4E834] block mb-4">{belief.num}</span>
                <h3 className="font-display text-xl text-[#F5F5F0] mb-3">{belief.title}</h3>
                <p className="text-[13px] text-[#8A8A9A] leading-relaxed">{belief.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Collaborate */}
      <section className="relative w-full py-[120px] px-6 lg:px-12 text-center" style={{ background: '#12121A' }}>
        <div className="max-w-[600px] mx-auto">
          <span className="label-accent block mb-6">JOIN THE MISSION</span>
          <h2 className="founder-animate font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-6">
            Building the Future Together
          </h2>
          <p className="founder-animate text-sm text-[#8A8A9A] leading-relaxed mb-8">
            This is not a solo endeavor. The future of human-AI coexistence will be built by
            researchers, engineers, designers, ethicists, and dreamers working together. If you
            believe in this vision, we want to hear from you.
          </p>
          <a
            href="/contact"
            className="founder-animate inline-block font-display text-sm font-medium px-10 py-4 bg-[#D4E834] text-[#0A0A0F] hover:bg-[#F5F5F0] transition-colors duration-300"
          >
            Get in Touch
          </a>
        </div>
      </section>
    </div>
  )
}
