import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const layers = [
  {
    title: 'Intelligence Layer',
    color: '#D4E834',
    items: ['Cognitive Brain', 'Emotion-to-Action Engine', 'Decision Intelligence', 'Reasoning Systems', 'Context Awareness'],
  },
  {
    title: 'Memory Layer',
    color: '#34D4E8',
    items: ['Adaptive Memory Core', 'Knowledge Graph', 'Long-term Context Store', 'Associative Retrieval', 'Memory Decay & Refresh'],
  },
  {
    title: 'Workflow Layer',
    color: '#E834D4',
    items: ['App-to-App Bridge', 'Life Operating Graph', 'Multi-Agent Coordination', 'Task Orchestration', 'Workflow Automation'],
  },
  {
    title: 'Interface Layer',
    color: '#F5F5F0',
    items: ['Voice Emotion Detection', 'Natural Language Processing', 'Visual Interface', 'API Gateway', 'Real-time Streaming'],
  },
  {
    title: 'Infrastructure Layer',
    color: '#8A8A9A',
    items: ['Distributed Compute', 'Edge Deployment', 'Model Serving', 'Data Pipeline', 'Security & Privacy'],
  },
]

export default function Technology() {
  const pageRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    window.scrollTo(0, 0)
    const page = pageRef.current
    if (!page) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        page.querySelectorAll('.tech-animate'),
        { y: 50, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.8, stagger: 0.12, ease: 'power3.out',
          scrollTrigger: { trigger: page.querySelector('.layers-section'), start: 'top 75%' },
        }
      )
    }, page)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={pageRef} className="pt-16">
      {/* Hero */}
      <section className="relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#0A0A0F' }}>
        <div className="max-w-[1200px] mx-auto">
          <span className="label-accent block mb-6">TECHNOLOGY</span>
          <h1
            className="font-display font-bold text-[#F5F5F0] mb-6"
            style={{ fontSize: 'clamp(36px, 6vw, 64px)', letterSpacing: '-1.92px', lineHeight: 1.0 }}
          >
            Technology Stack
          </h1>
          <p className="text-sm text-[#8A8A9A] leading-relaxed max-w-[600px]">
            A modern, scalable architecture built on proven technologies and cutting-edge research,
            designed for reliability, performance, and continuous evolution.
          </p>
        </div>
      </section>

      {/* Stack Layers */}
      <section className="layers-section relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#12121A' }}>
        <div className="max-w-[1000px] mx-auto">
          <span className="label-accent block mb-6">STACK ARCHITECTURE</span>
          <h2 className="font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-16">
            Layered Architecture
          </h2>

          <div className="space-y-6">
            {layers.map((layer, i) => (
              <div
                key={i}
                className="tech-animate p-6 border border-[rgba(245,245,240,0.08)] hover:border-[rgba(245,245,240,0.15)] transition-colors"
                style={{ background: 'rgba(26, 26, 37, 0.4)' }}
              >
                <div className="flex items-center gap-4 mb-4">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ background: layer.color, boxShadow: `0 0 12px ${layer.color}40` }}
                  />
                  <h3 className="font-display text-xl text-[#F5F5F0]">{layer.title}</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {layer.items.map((item, j) => (
                    <span
                      key={j}
                      className="px-3 py-1.5 text-xs border border-[rgba(245,245,240,0.08)] text-[#8A8A9A]"
                      style={{ background: 'rgba(10, 10, 15, 0.6)' }}
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Data & APIs */}
      <section className="relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#0A0A0F' }}>
        <div className="max-w-[1200px] mx-auto">
          <span className="label-accent block mb-6">DATA & APIs</span>
          <h2 className="font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-12">
            Data Architecture & APIs
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="tech-animate p-8 border border-[rgba(245,245,240,0.08)]" style={{ background: 'rgba(26, 26, 37, 0.6)' }}>
              <h3 className="font-display text-xl text-[#F5F5F0] mb-4">Data Layer</h3>
              <ul className="space-y-3">
                {['Vector Database (Pinecone/Weaviate)', 'Graph Database (Neo4j)', 'Time-series Store (TimescaleDB)', 'Object Storage (S3-compatible)', 'Cache Layer (Redis)'].map((item, i) => (
                  <li key={i} className="text-sm text-[#8A8A9A] flex items-center gap-2">
                    <span className="w-1 h-1 bg-[#D4E834] rounded-full" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="tech-animate p-8 border border-[rgba(245,245,240,0.08)]" style={{ background: 'rgba(26, 26, 37, 0.6)' }}>
              <h3 className="font-display text-xl text-[#F5F5F0] mb-4">API Infrastructure</h3>
              <ul className="space-y-3">
                {['RESTful API Gateway', 'WebSocket Real-time Streams', 'gRPC Internal Services', 'GraphQL Query Interface', 'Webhook Event System'].map((item, i) => (
                  <li key={i} className="text-sm text-[#8A8A9A] flex items-center gap-2">
                    <span className="w-1 h-1 bg-[#34D4E8] rounded-full" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Security */}
      <section className="relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#12121A' }}>
        <div className="max-w-[800px] mx-auto text-center">
          <span className="label-accent block mb-6">SECURITY</span>
          <h2 className="font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-6">
            Security & Privacy First
          </h2>
          <p className="text-sm text-[#8A8A9A] leading-relaxed mb-10">
            Every design decision prioritizes user privacy and data security. End-to-end encryption,
            zero-knowledge architectures, and transparent data handling policies ensure that your
            information remains yours.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {['End-to-End Encryption', 'Zero-Knowledge Proofs', 'Local Processing', 'GDPR Compliant'].map((item, i) => (
              <div key={i} className="tech-animate p-4 border border-[rgba(245,245,240,0.08)]" style={{ background: 'rgba(26, 26, 37, 0.6)' }}>
                <p className="font-display text-sm text-[#F5F5F0]">{item}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
