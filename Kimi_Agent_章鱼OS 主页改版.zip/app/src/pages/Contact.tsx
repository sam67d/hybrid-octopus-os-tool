import { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const collaborationCards = [
  {
    role: 'Researchers',
    desc: 'Join our research initiatives in emotional AI, cognitive architectures, and human-computer interaction. Publish with us.',
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="#D4E834" strokeWidth="1.5">
        <path d="M14 4C8 4 4 8 4 14s4 10 10 10 10-4 10-10" />
        <circle cx="14" cy="10" r="2" />
        <path d="M14 12v4" />
        <path d="M10 18c0-2 2-3 4-3s4 1 4 3" />
      </svg>
    ),
  },
  {
    role: 'Investors',
    desc: 'Support the development of next-generation AI. We are seeking visionary investors who believe in human-centric technology.',
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="#D4E834" strokeWidth="1.5">
        <path d="M4 20L10 12L14 16L24 6" />
        <path d="M18 6h6v6" />
      </svg>
    ),
  },
  {
    role: 'Universities',
    desc: 'Partner with us on research programs, student projects, and academic collaborations. Shape the future of AI education.',
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="#D4E834" strokeWidth="1.5">
        <path d="M4 12L14 6L24 12L14 18L4 12Z" />
        <path d="M20 14v6" />
        <path d="M8 12v6c0 3 3 5 6 5s6-2 6-5v-6" />
      </svg>
    ),
  },
  {
    role: 'Partners',
    desc: 'Integrate Hybrid Octopus OS into your products and services. Build the future of intelligent applications together.',
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="#D4E834" strokeWidth="1.5">
        <circle cx="10" cy="10" r="4" />
        <circle cx="18" cy="18" r="4" />
        <path d="M10 14v4c0 2 2 4 4 4h4" />
      </svg>
    ),
  },
  {
    role: 'Developers',
    desc: 'Contribute to the codebase, build modules, and help us create the most extensible AI platform in existence.',
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="#D4E834" strokeWidth="1.5">
        <polyline points="8 10 4 14 8 18" />
        <polyline points="20 10 24 14 20 18" />
        <line x1="12" y1="20" x2="16" y2="8" />
      </svg>
    ),
  },
  {
    role: 'Communities',
    desc: 'Join our global community of AI enthusiasts, ethicists, and futurists. Share ideas, provide feedback, and grow with us.',
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="#D4E834" strokeWidth="1.5">
        <circle cx="14" cy="8" r="3" />
        <path d="M6 22c0-4 4-6 8-6s8 2 8 6" />
        <circle cx="22" cy="10" r="2" />
        <circle cx="6" cy="10" r="2" />
      </svg>
    ),
  },
]

export default function Contact() {
  const pageRef = useRef<HTMLDivElement>(null)
  const [formData, setFormData] = useState({ name: '', email: '', role: '', message: '' })
  const [submitted, setSubmitted] = useState(false)

  useEffect(() => {
    window.scrollTo(0, 0)
    const page = pageRef.current
    if (!page) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        page.querySelectorAll('.contact-animate'),
        { y: 50, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.8, stagger: 0.1, ease: 'power3.out',
          scrollTrigger: { trigger: page.querySelector('.cards-grid'), start: 'top 80%' },
        }
      )
    }, page)

    return () => ctx.revert()
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 3000)
  }

  return (
    <div ref={pageRef} className="pt-16">
      {/* Hero */}
      <section className="relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#0A0A0F' }}>
        <div className="max-w-[900px] mx-auto text-center">
          <span className="label-accent block mb-6">COLLABORATE</span>
          <h1
            className="font-display font-bold text-[#F5F5F0] mb-6"
            style={{ fontSize: 'clamp(36px, 6vw, 64px)', letterSpacing: '-1.92px', lineHeight: 1.0 }}
          >
            Join the Mission
          </h1>
          <p className="text-sm text-[#8A8A9A] leading-relaxed max-w-[600px] mx-auto">
            We are building the future of human-AI coexistence, and we need visionary collaborators
            across every discipline. Whether you are a researcher, investor, developer, or dreamer —
            there is a place for you in this journey.
          </p>
        </div>
      </section>

      {/* Collaboration Cards */}
      <section className="cards-grid relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#12121A' }}>
        <div className="max-w-[1200px] mx-auto">
          <span className="label-accent block mb-6">HOW YOU CAN CONTRIBUTE</span>
          <h2 className="font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-12">
            Collaboration Opportunities
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {collaborationCards.map((card, i) => (
              <div
                key={i}
                className="contact-animate p-8 border border-[rgba(245,245,240,0.08)] hover:border-[#D4E834] hover:-translate-y-1 transition-all duration-300"
                style={{ background: 'rgba(26, 26, 37, 0.6)' }}
              >
                <div className="mb-4">{card.icon}</div>
                <h3 className="font-display text-xl text-[#F5F5F0] mb-3">{card.role}</h3>
                <p className="text-[13px] text-[#8A8A9A] leading-relaxed">{card.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#0A0A0F' }}>
        <div className="max-w-[800px] mx-auto">
          <span className="label-accent block mb-6">GET IN TOUCH</span>
          <h2 className="contact-animate font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-12">
            Start a Conversation
          </h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="font-mono-accent text-[11px] text-[#D4E834] uppercase tracking-[1.8px] block mb-2">
                  Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-transparent border-b border-[rgba(245,245,240,0.15)] text-[#F5F5F0] py-3 outline-none focus:border-[#D4E834] transition-colors placeholder:text-[#3A3A4A]"
                  placeholder="Your name"
                  required
                />
              </div>
              <div>
                <label className="font-mono-accent text-[11px] text-[#D4E834] uppercase tracking-[1.8px] block mb-2">
                  Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-transparent border-b border-[rgba(245,245,240,0.15)] text-[#F5F5F0] py-3 outline-none focus:border-[#D4E834] transition-colors placeholder:text-[#3A3A4A]"
                  placeholder="your@email.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="font-mono-accent text-[11px] text-[#D4E834] uppercase tracking-[1.8px] block mb-2">
                Role / Interest
              </label>
              <select
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                className="w-full bg-transparent border-b border-[rgba(245,245,240,0.15)] text-[#F5F5F0] py-3 outline-none focus:border-[#D4E834] transition-colors appearance-none cursor-pointer"
                style={{ background: '#0A0A0F' }}
              >
                <option value="" className="bg-[#0A0A0F]">Select your role</option>
                <option value="researcher" className="bg-[#0A0A0F]">Researcher</option>
                <option value="investor" className="bg-[#0A0A0F]">Investor</option>
                <option value="developer" className="bg-[#0A0A0F]">Developer</option>
                <option value="partner" className="bg-[#0A0A0F]">Strategic Partner</option>
                <option value="university" className="bg-[#0A0A0F]">University / Institution</option>
                <option value="community" className="bg-[#0A0A0F]">Community Member</option>
                <option value="other" className="bg-[#0A0A0F]">Other</option>
              </select>
            </div>

            <div>
              <label className="font-mono-accent text-[11px] text-[#D4E834] uppercase tracking-[1.8px] block mb-2">
                Message
              </label>
              <textarea
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                rows={4}
                className="w-full bg-transparent border-b border-[rgba(245,245,240,0.15)] text-[#F5F5F0] py-3 outline-none focus:border-[#D4E834] transition-colors resize-none placeholder:text-[#3A3A4A]"
                placeholder="Tell us about your interest..."
                required
              />
            </div>

            <div className="pt-4">
              <button
                type="submit"
                className="font-display text-sm font-medium px-10 py-4 bg-[#D4E834] text-[#0A0A0F] hover:bg-[#F5F5F0] transition-colors duration-300"
              >
                {submitted ? 'Message Sent!' : 'Send Message'}
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* Key Message */}
      <section className="relative w-full py-[100px] px-6 lg:px-12 text-center" style={{ background: '#12121A' }}>
        <div className="max-w-[600px] mx-auto">
          <blockquote>
            <p className="font-display text-2xl text-[#F5F5F0] italic leading-relaxed mb-6">
              "This is not another chatbot. This is an exploration into the future of Human-AI
              Coexistence."
            </p>
            <p className="font-mono-accent text-xs text-[#D4E834] uppercase tracking-[1.8px]">
              — The Hybrid Octopus OS Team
            </p>
          </blockquote>
        </div>
      </section>
    </div>
  )
}
