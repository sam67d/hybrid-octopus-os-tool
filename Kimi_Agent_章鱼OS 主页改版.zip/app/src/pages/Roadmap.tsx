import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const phases = [
  {
    phase: 'PHASE 1',
    title: 'Foundation',
    period: '2024 - 2025',
    status: 'In Progress',
    items: [
      'Core architecture design and implementation',
      'Initial 8 intelligence modules',
      'Basic memory and reasoning systems',
      'Cognitive Brain Layer prototype',
      'Adaptive Memory System v1',
      'Internal testing and validation',
    ],
  },
  {
    phase: 'PHASE 2',
    title: 'Integration',
    period: '2025 - 2026',
    status: 'Upcoming',
    items: [
      'Voice interface with emotion detection',
      'App-to-App Intelligence Layer',
      'Emotion-to-Action Engine v1',
      'First beta release to select partners',
      'Decision Intelligence Engine',
      'Developer preview API',
    ],
  },
  {
    phase: 'PHASE 3',
    title: 'Evolution',
    period: '2026 - 2027',
    status: 'Planned',
    items: [
      'Self-Reflection & Growth System',
      'Advanced decision engine v2',
      'Multi-Agent Workflow Coordination',
      'Third-party developer platform',
      'Dream Builder AI',
      'Future Scenario Simulation',
    ],
  },
  {
    phase: 'PHASE 4',
    title: 'Coexistence',
    period: '2027 - 2030',
    status: 'Vision',
    items: [
      'Full human-AI collaboration suite',
      'Enterprise deployment ready',
      'Global research partnerships',
      'Open-source community modules',
      'Context-Aware Reasoning at scale',
      'Continuous self-evolving system',
    ],
  },
]

export default function Roadmap() {
  const pageRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    window.scrollTo(0, 0)
    const page = pageRef.current
    if (!page) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        page.querySelectorAll('.roadmap-animate'),
        { y: 60, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.8, stagger: 0.15, ease: 'power3.out',
          scrollTrigger: { trigger: page.querySelector('.phases-grid'), start: 'top 75%' },
        }
      )
    }, page)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={pageRef} className="pt-16">
      {/* Hero */}
      <section className="relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#0A0A0F' }}>
        <div className="max-w-[1200px] mx-auto">
          <span className="label-accent block mb-6">ROADMAP</span>
          <h1
            className="font-display font-bold text-[#F5F5F0] mb-6"
            style={{ fontSize: 'clamp(36px, 6vw, 64px)', letterSpacing: '-1.92px', lineHeight: 1.0 }}
          >
            Vision & Roadmap
          </h1>
          <p className="text-sm text-[#8A8A9A] leading-relaxed max-w-[600px]">
            Our journey from concept to human-AI coexistence, built through four strategic phases
            of research, development, and collaboration.
          </p>
        </div>
      </section>

      {/* Timeline */}
      <section className="phases-grid relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#12121A' }}>
        <div className="max-w-[1200px] mx-auto">
          <div className="space-y-12">
            {phases.map((p, i) => (
              <div
                key={i}
                className="roadmap-animate grid grid-cols-1 lg:grid-cols-[200px_1fr] gap-8 items-start"
              >
                <div className="flex flex-col">
                  <span className="font-mono-accent text-xs text-[#D4E834] mb-1">{p.phase}</span>
                  <span className="font-display text-lg text-[#F5F5F0]">{p.period}</span>
                  <span
                    className="text-xs mt-2 px-2 py-1 inline-block w-fit"
                    style={{
                      color: p.status === 'In Progress' ? '#D4E834' : '#8A8A9A',
                      border: `1px solid ${p.status === 'In Progress' ? '#D4E834' : 'rgba(245,245,240,0.08)'}`,
                      background: p.status === 'In Progress' ? 'rgba(212,232,52,0.1)' : 'transparent',
                    }}
                  >
                    {p.status}
                  </span>
                </div>
                <div className="p-8 border border-[rgba(245,245,240,0.08)]" style={{ background: 'rgba(26, 26, 37, 0.6)' }}>
                  <h3 className="font-display text-2xl text-[#F5F5F0] mb-6">{p.title}</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {p.items.map((item, j) => (
                      <div key={j} className="flex items-start gap-2">
                        <span className="w-1 h-1 bg-[#D4E834] rounded-full mt-2 flex-shrink-0" />
                        <span className="text-sm text-[#8A8A9A]">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Vision Statement */}
      <section className="relative w-full py-[120px] px-6 lg:px-12 text-center" style={{ background: '#0A0A0F' }}>
        <div
          className="absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(212, 232, 52, 0.03) 0%, transparent 70%)',
          }}
        />
        <div className="relative max-w-[800px] mx-auto">
          <span className="label-accent block mb-6">THE VISION</span>
          <h2
            className="font-display font-bold text-[#F5F5F0] mb-8"
            style={{ fontSize: 'clamp(28px, 4vw, 48px)', letterSpacing: '-1.44px', lineHeight: 1.1 }}
          >
            By 2030, Hybrid Octopus OS aims to power the most human-centric digital experiences on
            Earth
          </h2>
          <p className="text-sm text-[#8A8A9A] leading-relaxed mb-10">
            From personal assistants that truly know you, to research tools that think with you, to
            creative partners that inspire you. We are not building a product. We are building a
            new kind of mind.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
            {[
              { value: '16', label: 'Intelligence Modules' },
              { value: '4', label: 'Development Phases' },
              { value: '2030', label: 'Full Vision Target' },
            ].map((stat, i) => (
              <div key={i} className="p-6 border border-[rgba(245,245,240,0.08)]" style={{ background: 'rgba(26, 26, 37, 0.6)' }}>
                <p className="font-display text-4xl text-[#D4E834] font-bold mb-2">{stat.value}</p>
                <p className="text-xs text-[#8A8A9A]">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
