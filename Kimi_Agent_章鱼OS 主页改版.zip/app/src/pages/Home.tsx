import { useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import NeuralBrainCanvas from '../components/NeuralBrainCanvas'
import ModuleRing from '../components/ModuleRing'
import RadialHub from '../components/RadialHub'
import PerspectiveLines from '../components/PerspectiveLines'
import WaveBars from '../components/WaveBars'

gsap.registerPlugin(ScrollTrigger)

export default function Home() {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <div className="relative">
      <HeroSection />
      <ProblemSection />
      <WhatIsSection />
      <CoreModulesSection />
      <ArchitecturePreviewSection />
      <PhilosophySection />
      <VisionSection />
      <RoadmapSection />
      <CTASection />
    </div>
  )
}

/* ─── HERO SECTION (Redesigned) ─── */
function HeroSection() {
  const heroRef = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)
  const visualRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const content = contentRef.current
    const visual = visualRef.current
    if (!content || !visual) return

    const ctx = gsap.context(() => {
      // Staggered entrance for left content
      gsap.fromTo(
        content.querySelectorAll('.hero-el'),
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.9,
          stagger: 0.12,
          ease: 'power3.out',
          delay: 0.2,
        }
      )

      // Visual fades in
      gsap.fromTo(
        visual,
        { opacity: 0, scale: 0.95 },
        { opacity: 1, scale: 1, duration: 1.4, ease: 'power2.out', delay: 0.4 }
      )
    })

    return () => ctx.revert()
  }, [])

  return (
    <section
      ref={heroRef}
      className="relative w-full min-h-screen flex items-center overflow-hidden"
      style={{ background: '#0A0A0F' }}
    >
      {/* Subtle background glow */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
        style={{
          width: '80%',
          height: '80%',
          background: 'radial-gradient(ellipse at center, rgba(52, 212, 232, 0.03) 0%, transparent 60%)',
        }}
      />

      <div className="relative z-10 w-full max-w-[1200px] mx-auto px-6 lg:px-12 py-32">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          {/* Left: Content */}
          <div ref={contentRef} className="order-2 lg:order-1">
            <span className="hero-el label-accent block mb-6">
              A Human-Centric Living AI Ecosystem
            </span>

            <h1
              className="hero-el font-display font-bold text-[#F5F5F0] leading-[1.05] tracking-[-1.5px] mb-6"
              style={{ fontSize: 'clamp(36px, 4.5vw, 56px)' }}
            >
              Not Another AI Tool.<br />
              <span className="text-[#D4E834]">A Living AI Ecosystem.</span>
            </h1>

            <p className="hero-el text-base text-[#8A8A9A] leading-[1.7] max-w-[480px] mb-10">
              Hybrid Octopus OS combines Emotion, Memory, Reasoning, Voice, Decision Intelligence
              and Connected Workflows into a single adaptive system — designed to understand, not
              just respond.
            </p>

            <div className="hero-el flex flex-wrap items-center gap-4">
              <Link
                to="/features"
                className="font-display text-sm font-medium px-8 py-3.5 bg-[#D4E834] text-[#0A0A0F] hover:bg-[#F5F5F0] transition-colors duration-300"
              >
                Explore the Ecosystem
              </Link>
              <Link
                to="/contact"
                className="font-display text-sm font-medium px-8 py-3.5 border border-[rgba(245,245,240,0.2)] text-[#F5F5F0] hover:border-[#F5F5F0] hover:bg-[rgba(245,245,240,0.05)] transition-all duration-300"
              >
                Join the Mission
              </Link>
            </div>

            {/* Trust indicators */}
            <div className="hero-el flex items-center gap-8 mt-14 pt-8 border-t border-[rgba(245,245,240,0.06)]">
              {[
                { num: '16', label: 'AI Modules' },
                { num: '4', label: 'Phases' },
                { num: '1', label: 'Unified Mind' },
              ].map((stat) => (
                <div key={stat.label}>
                  <p className="font-display text-xl text-[#F5F5F0] font-bold">{stat.num}</p>
                  <p className="text-[11px] text-[#8A8A9A] mt-0.5 uppercase tracking-wider">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Neural Brain Visualization */}
          <div
            ref={visualRef}
            className="order-1 lg:order-2 flex items-center justify-center"
            style={{ height: 'clamp(320px, 50vh, 520px)', opacity: 0 }}
          >
            <div className="relative w-full h-full">
              {/* Subtle ring behind brain */}
              <div
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
                style={{
                  width: '70%',
                  height: '70%',
                  border: '1px solid rgba(52, 212, 232, 0.06)',
                  borderRadius: '50%',
                }}
              />
              <div
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
                style={{
                  width: '85%',
                  height: '85%',
                  border: '1px solid rgba(52, 212, 232, 0.04)',
                  borderRadius: '50%',
                }}
              />
              <NeuralBrainCanvas />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom gradient fade to next section */}
      <div
        className="absolute bottom-0 left-0 w-full h-24 pointer-events-none"
        style={{ background: 'linear-gradient(to bottom, transparent, #0A0A0F)' }}
      />
    </section>
  )
}

/* ─── PROBLEM SECTION ─── */
function ProblemSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        section.querySelector('.problem-left'),
        { x: -60, opacity: 0 },
        {
          x: 0, opacity: 1, duration: 0.9, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 80%' },
        }
      )
      gsap.fromTo(
        section.querySelector('.problem-right'),
        { x: 60, opacity: 0 },
        {
          x: 0, opacity: 1, duration: 0.9, delay: 0.2, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 80%' },
        }
      )
    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <section
      id="philosophy"
      ref={sectionRef}
      className="relative w-full py-[120px] px-6 lg:px-12"
      style={{ background: '#0A0A0F' }}
    >
      <div
        className="absolute top-0 left-0 w-full h-px"
        style={{ background: 'linear-gradient(90deg, transparent, #D4E834 50%, transparent)' }}
      />
      <div className="max-w-[1200px] mx-auto grid grid-cols-1 md:grid-cols-[55%_45%] gap-16 items-center">
        <div className="problem-left">
          <span className="label-accent block mb-6">THE FRAGMENTATION PROBLEM</span>
          <h2 className="font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px]">
            Today's AI tools are brilliant in isolation — but they don't talk to each other. Emotion
            engines, memory systems, voice interfaces, and reasoning layers operate in silos, creating
            fragmented experiences that feel mechanical rather than intelligent.
          </h2>
        </div>
        <div className="problem-right flex flex-col items-center">
          <ModuleRing />
          <p className="text-sm text-[#8A8A9A] mt-8 text-center">
            Sixteen specialized intelligence modules. One unified system.
          </p>
        </div>
      </div>
    </section>
  )
}

/* ─── WHAT IS SECTION ─── */
function WhatIsSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        section.querySelector('.what-heading'),
        { y: 40, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.8, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 75%' },
        }
      )
      gsap.fromTo(
        section.querySelector('.what-body'),
        { y: 40, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.8, delay: 0.2, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 75%' },
        }
      )
      gsap.fromTo(
        section.querySelectorAll('.feature-card'),
        { y: 60, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.7, stagger: 0.12, delay: 0.4, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 75%' },
        }
      )
    }, section)

    return () => ctx.revert()
  }, [])

  const features = [
    {
      icon: (
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" stroke="#D4E834" strokeWidth="1.5">
          <path d="M16 28C16 28 26 22 26 14C26 8.5 21.5 4 16 4C10.5 4 6 8.5 6 14C6 22 16 28 16 28Z" />
          <path d="M12 14C12 14 13 12 16 12C19 12 20 14 20 14" />
        </svg>
      ),
      title: 'Emotion-to-Action',
      desc: 'Adaptive emotional understanding that influences system behavior and decisions in real-time.',
    },
    {
      icon: (
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" stroke="#D4E834" strokeWidth="1.5">
          <circle cx="10" cy="12" r="3" />
          <circle cx="22" cy="12" r="3" />
          <circle cx="16" cy="22" r="3" />
          <line x1="10" y1="12" x2="22" y2="12" />
          <line x1="10" y1="12" x2="16" y2="22" />
          <line x1="22" y1="12" x2="16" y2="22" />
        </svg>
      ),
      title: 'Cognitive Brain',
      desc: 'A reasoning layer connecting multiple intelligence systems into coherent thought processes.',
    },
    {
      icon: (
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" stroke="#D4E834" strokeWidth="1.5">
          <path d="M16 4C16 4 8 10 8 18C8 24 11 28 16 28C21 28 24 24 24 18C24 10 16 4 16 4Z" />
          <path d="M16 10C16 10 12 14 12 18C12 21 14 24 16 24" />
        </svg>
      ),
      title: 'Adaptive Memory',
      desc: 'Long-term contextual intelligence that builds personal knowledge graphs across every interaction.',
    },
    {
      icon: (
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" stroke="#D4E834" strokeWidth="1.5">
          <path d="M4 16C4 16 6 10 10 10C14 10 16 16 16 16" />
          <path d="M16 16C16 16 18 22 22 22C26 22 28 16 28 16" />
          <circle cx="16" cy="16" r="2" />
        </svg>
      ),
      title: 'Voice Intelligence',
      desc: 'Emotion-aware voice processing with natural language understanding and generation.',
    },
    {
      icon: (
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" stroke="#D4E834" strokeWidth="1.5">
          <path d="M16 4L28 16L16 28L4 16L16 4Z" />
          <path d="M16 10L22 16L16 22L10 16L16 10Z" />
        </svg>
      ),
      title: 'Decision Engine',
      desc: 'Explainable decision-making with transparent reasoning chains and confidence scoring.',
    },
  ]

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative w-full py-[120px] px-6 lg:px-12"
      style={{ background: '#12121A' }}
    >
      <div className="max-w-[800px] mx-auto text-center mb-20">
        <span className="label-accent block mb-6">WHAT IS HYBRID OCTOPUS OS</span>
        <h2 className="what-heading font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-6">
          An AI ecosystem that unifies emotion, memory, reasoning, voice, decision intelligence, and
          connected workflows into a single adaptive system. It doesn't just respond — it
          understands, remembers, adapts, and grows alongside you.
        </h2>
        <p className="what-body text-sm text-[#8A8A9A] leading-relaxed">
          Built on a modular architecture with sixteen core intelligence engines, Hybrid Octopus OS
          creates a living digital mind where every component communicates, learns from every
          interaction, and evolves to serve human needs more deeply over time.
        </p>
      </div>

      <div className="max-w-[1200px] mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
        {features.map((f, i) => (
          <div
            key={i}
            className="feature-card p-8 border border-[rgba(245,245,240,0.08)] hover:border-[#D4E834] hover:-translate-y-1 transition-all duration-300"
            style={{ background: 'rgba(26, 26, 37, 0.6)' }}
          >
            <div className="mb-4">{f.icon}</div>
            <h3 className="font-display text-lg text-[#F5F5F0] mb-2">{f.title}</h3>
            <p className="text-[13px] text-[#8A8A9A] leading-relaxed">{f.desc}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

/* ─── CORE MODULES SECTION ─── */
function CoreModulesSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        section.querySelectorAll('.module-card'),
        { y: 80, opacity: 0, scale: 0.95 },
        {
          y: 0, opacity: 1, scale: 1, duration: 0.7, stagger: 0.08, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 70%' },
        }
      )
    }, section)

    return () => ctx.revert()
  }, [])

  const modules = [
    { num: '01', title: 'E2A Engine', desc: 'Emotion-to-Action Intelligence — Transforms emotional signals into actionable system responses with adaptive weighting.' },
    { num: '02', title: 'Cognitive Layer', desc: 'Cognitive Brain Layer — Cross-system reasoning that synthesizes inputs from multiple intelligence modules.' },
    { num: '03', title: 'Heartbeat', desc: 'AI Heartbeat Visualization — Dynamic system state representation showing real-time health and activity across all modules.' },
    { num: '04', title: 'Memory Core', desc: 'Adaptive Memory System — Contextual long-term storage with associative retrieval and decay mechanisms.' },
    { num: '05', title: 'Dream Builder', desc: 'Dream Builder AI — Future scenario generation and imagination systems for creative problem-solving.' },
    { num: '06', title: 'Simulator', desc: 'Future Scenario Simulation — Predictive modeling engine that runs what-if analyses across connected systems.' },
    { num: '07', title: 'Voice Core', desc: 'Voice Emotion Detection — Multi-modal voice analysis detecting emotional content, intent, and speaker state.' },
    { num: '08', title: 'App Bridge', desc: 'App-to-App Intelligence — Cross-platform workflow connections that unify disparate tools and data sources.' },
    { num: '09', title: 'Life Graph', desc: 'Life Operating Graph — Relationship mapping between systems, context entities, and decision pathways.' },
    { num: '10', title: 'Decision Core', desc: 'Decision Intelligence Engine — Explainable AI decision-making with confidence scoring and reasoning chains.' },
    { num: '11', title: 'Reflection', desc: 'Self-Reflection System — Continuous system evolution through performance analysis and self-optimization.' },
    { num: '12', title: 'Behavior Core', desc: 'Human Behavior Learning — Adaptive personalization that learns individual patterns and preferences over time.' },
  ]

  return (
    <section
      id="modules"
      ref={sectionRef}
      className="relative w-full py-[120px] px-6 lg:px-12"
      style={{ background: '#0A0A0F' }}
    >
      {/* Dot grid pattern */}
      <div
        className="absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage: 'radial-gradient(circle, #D4E834 1.5px, transparent 1.5px)',
          backgroundSize: '40px 40px',
        }}
      />

      <div className="max-w-[1200px] mx-auto relative">
        <span className="label-accent block mb-6">CORE INTELLIGENCE MODULES</span>
        <h2 className="font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-12">
          Sixteen Engines. One Mind.
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {modules.map((m) => (
            <div
              key={m.num}
              className="module-card p-8 border border-[rgba(245,245,240,0.08)] hover:border-[#D4E834] hover:-translate-y-1 transition-all duration-300"
              style={{ background: 'rgba(26, 26, 37, 0.6)', aspectRatio: '3/2' }}
            >
              <span className="font-mono-accent text-xs text-[#D4E834] block mb-3">{m.num}</span>
              <h3 className="font-display text-xl text-[#F5F5F0] mb-2">{m.title}</h3>
              <p className="text-[13px] text-[#8A8A9A] leading-relaxed line-clamp-3">{m.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ─── ARCHITECTURE PREVIEW SECTION ─── */
function ArchitecturePreviewSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        section.querySelector('.arch-text'),
        { x: -80, opacity: 0 },
        {
          x: 0, opacity: 1, duration: 1, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 60%' },
        }
      )
      gsap.fromTo(
        section.querySelector('.arch-canvas'),
        { opacity: 0, scale: 0.9 },
        {
          opacity: 1, scale: 1, duration: 1, delay: 0.3, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 60%' },
        }
      )
    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <section
      id="architecture"
      ref={sectionRef}
      className="relative w-full min-h-screen flex items-center py-[120px] px-6 lg:px-12"
      style={{ background: '#12121A' }}
    >
      <div className="max-w-[1200px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center w-full">
        <div className="arch-text">
          <span className="label-accent block mb-6">SYSTEM ARCHITECTURE</span>
          <h2 className="font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-6">
            A Neural Architecture Built for Evolution
          </h2>
          <p className="text-sm text-[#8A8A9A] leading-relaxed">
            The system is organized in concentric layers — from core cognitive functions at the
            center to external integrations at the edges. Every layer communicates bidirectionally,
            creating a true neural network rather than a linear pipeline.
          </p>
        </div>
        <div className="arch-canvas flex items-center justify-center">
          <RadialHub />
        </div>
      </div>
    </section>
  )
}

/* ─── PHILOSOPHY SECTION ─── */
function PhilosophySection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        section.querySelector('.philosophy-text'),
        { y: 50, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.9, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 70%' },
        }
      )
      gsap.fromTo(
        section.querySelector('.philosophy-canvas'),
        { opacity: 0 },
        {
          opacity: 1, duration: 1.2, delay: 0.4, ease: 'power2.out',
          scrollTrigger: { trigger: section, start: 'top 70%' },
        }
      )
    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-[120px] px-6 lg:px-12"
      style={{ background: '#0A0A0F' }}
    >
      <div className="max-w-[800px] mx-auto text-center mb-16 philosophy-text">
        <span className="label-accent block mb-6">PHILOSOPHY</span>
        <h2 className="font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-6">
          Designed for Human-AI Coexistence
        </h2>
        <p className="text-sm text-[#8A8A9A] leading-relaxed">
          We believe the future of intelligence is not artificial replacing human — it's hybrid,
          collaborative, and deeply interwoven. Hybrid Octopus OS is built on the principle that
          technology should amplify human capability, not diminish it.
        </p>
      </div>

      <div className="philosophy-canvas w-full overflow-hidden" style={{ height: '300px' }}>
        <PerspectiveLines />
      </div>
    </section>
  )
}

/* ─── VISION SECTION ─── */
function VisionSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        section.querySelector('.vision-left'),
        { x: -60, opacity: 0 },
        {
          x: 0, opacity: 1, duration: 0.9, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 70%' },
        }
      )
      gsap.fromTo(
        section.querySelector('.vision-right'),
        { opacity: 0, y: 40 },
        {
          opacity: 1, y: 0, duration: 0.9, delay: 0.3, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 70%' },
        }
      )
    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <section
      id="mission"
      ref={sectionRef}
      className="relative w-full py-[120px] px-6 lg:px-12"
      style={{ background: '#12121A' }}
    >
      <div className="max-w-[1200px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div className="vision-left">
          <span className="label-accent block mb-6">THE VISION</span>
          <h2 className="font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-6">
            A World Where Intelligence Serves Humanity
          </h2>
          <p className="text-sm text-[#8A8A9A] leading-relaxed">
            By 2030, Hybrid Octopus OS aims to power the most human-centric digital experiences on
            Earth — from personal assistants that truly know you, to research tools that think with
            you, to creative partners that inspire you. We are not building a product. We are
            building a new kind of mind.
          </p>
        </div>
        <div className="vision-right">
          <WaveBars />
        </div>
      </div>
    </section>
  )
}

/* ─── ROADMAP SECTION ─── */
function RoadmapSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        section.querySelectorAll('.roadmap-card'),
        { y: 60, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.8, stagger: 0.15, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 75%' },
        }
      )
    }, section)

    return () => ctx.revert()
  }, [])

  const phases = [
    { phase: 'PHASE 1', title: 'Foundation', desc: 'Core architecture, initial 8 intelligence modules, basic memory and reasoning systems.' },
    { phase: 'PHASE 2', title: 'Integration', desc: 'Voice interface, emotion detection, app-to-app connections, first beta release.' },
    { phase: 'PHASE 3', title: 'Evolution', desc: 'Self-reflection system, advanced decision engine, third-party developer platform.' },
    { phase: 'PHASE 4', title: 'Coexistence', desc: 'Full human-AI collaboration suite, enterprise deployment, global research partnerships.' },
  ]

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-[120px] px-6 lg:px-12"
      style={{ background: '#0A0A0F' }}
    >
      <div className="max-w-[1200px] mx-auto">
        <span className="label-accent block mb-6">ROADMAP</span>
        <h2 className="font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-12">
          Building the Future, One Phase at a Time
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {phases.map((p) => (
            <div
              key={p.phase}
              className="roadmap-card p-10 border border-[rgba(245,245,240,0.08)] hover:border-[#D4E834] transition-colors duration-300"
              style={{ background: 'rgba(26, 26, 37, 0.6)' }}
            >
              <span className="font-mono-accent text-xs text-[#D4E834] block mb-4">{p.phase}</span>
              <h3 className="font-display text-[22px] text-[#F5F5F0] mb-3">{p.title}</h3>
              <p className="text-[13px] text-[#8A8A9A] leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ─── CTA SECTION ─── */
function CTASection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        section.querySelector('.cta-heading'),
        { y: 60, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 1, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 75%' },
        }
      )
      gsap.fromTo(
        section.querySelectorAll('.cta-sub'),
        { y: 40, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.8, stagger: 0.2, delay: 0.3, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 75%' },
        }
      )
    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <section
      id="collaborate"
      ref={sectionRef}
      className="relative w-full py-[160px] px-6 lg:px-12 text-center"
      style={{
        background: '#0A0A0F',
      }}
    >
      <div
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(ellipse at center, rgba(212, 232, 52, 0.05) 0%, transparent 70%)',
        }}
      />
      <div className="relative max-w-[800px] mx-auto">
        <h2
          className="cta-heading font-display font-bold text-[#F5F5F0] mb-6"
          style={{ fontSize: 'clamp(36px, 5vw, 64px)', letterSpacing: '-1.92px', lineHeight: 1.0 }}
        >
          The Future of Intelligence is Hybrid
        </h2>
        <p className="cta-sub text-sm text-[#8A8A9A] mb-10">
          Join researchers, engineers, and visionaries building the next evolution of AI.
        </p>
        <div className="cta-sub flex flex-col sm:flex-row items-center justify-center gap-6">
          <Link
            to="/features"
            className="font-display text-sm font-medium px-10 py-4 bg-[#D4E834] text-[#0A0A0F] hover:bg-[#F5F5F0] transition-colors duration-300"
          >
            Explore the Ecosystem
          </Link>
          <Link
            to="/contact"
            className="font-display text-sm font-medium px-10 py-4 border border-[#F5F5F0] text-[#F5F5F0] hover:bg-[#F5F5F0] hover:text-[#0A0A0F] transition-all duration-300"
          >
            Join as Collaborator
          </Link>
        </div>
      </div>
    </section>
  )
}
