import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import RadialHub from '../components/RadialHub'

gsap.registerPlugin(ScrollTrigger)

const allModules = [
  { num: '01', title: 'E2A Engine', fullTitle: 'Emotion-to-Action Intelligence', desc: 'Adaptive emotional understanding that influences system behavior and decisions in real-time. Transforms emotional signals into actionable system responses with adaptive weighting.' },
  { num: '02', title: 'Cognitive Layer', fullTitle: 'Cognitive Brain Layer', desc: 'A reasoning layer connecting multiple intelligence systems into coherent thought processes. Cross-system reasoning synthesizes inputs from multiple modules.' },
  { num: '03', title: 'Heartbeat', fullTitle: 'AI Heartbeat Visualization', desc: 'Dynamic system state representation showing real-time health and activity across all modules. A living pulse of the entire ecosystem.' },
  { num: '04', title: 'Memory Core', fullTitle: 'Adaptive Memory System', desc: 'Contextual long-term storage with associative retrieval and decay mechanisms. Builds persistent knowledge graphs across every interaction.' },
  { num: '05', title: 'Dream Builder', fullTitle: 'Dream Builder AI', desc: 'Future scenario generation and imagination systems for creative problem-solving. Envisions possibilities beyond current constraints.' },
  { num: '06', title: 'Simulator', fullTitle: 'Future Scenario Simulation', desc: 'Predictive modeling engine that runs what-if analyses across connected systems. Tests outcomes before decisions are made.' },
  { num: '07', title: 'Voice Core', fullTitle: 'Voice Emotion Detection', desc: 'Multi-modal voice analysis detecting emotional content, intent, and speaker state. Natural language understanding with emotional awareness.' },
  { num: '08', title: 'App Bridge', fullTitle: 'App-to-App Intelligence', desc: 'Cross-platform workflow connections that unify disparate tools and data sources. Seamless integration across your digital workspace.' },
  { num: '09', title: 'Life Graph', fullTitle: 'Life Operating Graph', desc: 'Relationship mapping between systems, context entities, and decision pathways. A dynamic map of how everything connects.' },
  { num: '10', title: 'Decision Core', fullTitle: 'Decision Intelligence Engine', desc: 'Explainable AI decision-making with confidence scoring and reasoning chains. Transparent logic you can trust and verify.' },
  { num: '11', title: 'Reflection', fullTitle: 'Self-Reflection & Growth System', desc: 'Continuous system evolution through performance analysis and self-optimization. Learns from its own successes and failures.' },
  { num: '12', title: 'Behavior Core', fullTitle: 'Human Behavior Learning', desc: 'Adaptive personalization that learns individual patterns and preferences over time. Gets better at serving you the more you use it.' },
  { num: '13', title: 'Context Engine', fullTitle: 'Context-Aware Reasoning', desc: 'Context-sensitive intelligence that understands the situational landscape before making decisions or recommendations.' },
  { num: '14', title: 'Multi-Agent', fullTitle: 'Multi-Agent Workflow Coordination', desc: 'Multiple AI agents collaborating together on complex tasks, each bringing specialized capabilities to the collective effort.' },
  { num: '15', title: 'Growth Core', fullTitle: 'Self-Reflection & Growth System', desc: 'System evolution and learning through continuous self-assessment, performance metrics, and adaptive improvement cycles.' },
  { num: '16', title: 'Reasoning', fullTitle: 'Advanced Reasoning Engine', desc: 'Multi-step logical inference with causal modeling, analogical reasoning, and abstract pattern recognition capabilities.' },
]

export default function Features() {
  const pageRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    window.scrollTo(0, 0)
    const page = pageRef.current
    if (!page) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        page.querySelectorAll('.feature-animate'),
        { y: 60, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.8, stagger: 0.1, ease: 'power3.out',
          scrollTrigger: { trigger: page.querySelector('.modules-grid'), start: 'top 75%' },
        }
      )
    }, page)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={pageRef} className="pt-16">
      {/* Hero */}
      <section className="relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#0A0A0F' }}>
        <div className="max-w-[1200px] mx-auto">
          <span className="label-accent block mb-6">ARCHITECTURE</span>
          <h1
            className="font-display font-bold text-[#F5F5F0] mb-6"
            style={{ fontSize: 'clamp(36px, 6vw, 64px)', letterSpacing: '-1.92px', lineHeight: 1.0 }}
          >
            Features & Architecture
          </h1>
          <p className="text-sm text-[#8A8A9A] leading-relaxed max-w-[600px]">
            A modular architecture with sixteen core intelligence engines, each designed to
            communicate, learn, and evolve as part of a unified digital mind.
          </p>
        </div>
      </section>

      {/* Architecture Diagram */}
      <section className="relative w-full py-[80px] px-6 lg:px-12" style={{ background: '#12121A' }}>
        <div className="max-w-[1200px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="label-accent block mb-6">SYSTEM OVERVIEW</span>
              <h2 className="font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-6">
                Neural Architecture at a Glance
              </h2>
              <p className="text-sm text-[#8A8A9A] leading-relaxed">
                At the center of Hybrid Octopus OS lies the Cognitive Core — a bidirectional
                communication hub that connects all intelligence modules. Unlike traditional
                AI pipelines that process data linearly, our architecture allows every module to
                influence and be influenced by every other module in real-time.
              </p>
            </div>
            <div>
              <RadialHub />
            </div>
          </div>
        </div>
      </section>

      {/* All Modules Grid */}
      <section className="modules-grid relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#0A0A0F' }}>
        <div
          className="absolute inset-0 opacity-[0.06]"
          style={{
            backgroundImage: 'radial-gradient(circle, #D4E834 1.5px, transparent 1.5px)',
            backgroundSize: '40px 40px',
          }}
        />
        <div className="max-w-[1200px] mx-auto relative">
          <span className="label-accent block mb-6">ALL MODULES</span>
          <h2 className="font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-12">
            Complete Intelligence Stack
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {allModules.map((m) => (
              <div
                key={m.num}
                className="feature-animate p-8 border border-[rgba(245,245,240,0.08)] hover:border-[#D4E834] hover:-translate-y-1 transition-all duration-300"
                style={{ background: 'rgba(26, 26, 37, 0.6)' }}
              >
                <div className="flex items-center gap-3 mb-4">
                  <span className="font-mono-accent text-xs text-[#D4E834]">{m.num}</span>
                  <h3 className="font-display text-xl text-[#F5F5F0]">{m.title}</h3>
                </div>
                <p className="font-mono-accent text-[10px] text-[#8A8A9A] uppercase tracking-wider mb-3">
                  {m.fullTitle}
                </p>
                <p className="text-[13px] text-[#8A8A9A] leading-relaxed">{m.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Key Differentiators */}
      <section className="relative w-full py-[120px] px-6 lg:px-12" style={{ background: '#12121A' }}>
        <div className="max-w-[1200px] mx-auto">
          <span className="label-accent block mb-6">DIFFERENTIATORS</span>
          <h2 className="font-display text-[32px] text-[#F5F5F0] leading-[1.2] tracking-[-0.96px] mb-12">
            What Makes Us Different
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'Unified, Not Fragmented',
                desc: 'While most AI tools specialize in one area, Hybrid Octopus OS unifies emotion, memory, reasoning, voice, and decision-making into a single coherent system that thinks holistically.',
              },
              {
                title: 'Emotionally Intelligent',
                desc: 'Our Emotion-to-Action engine doesn\'t just detect sentiment — it understands emotional nuance and uses that understanding to inform every subsequent interaction and decision.',
              },
              {
                title: 'Continuously Evolving',
                desc: 'Through self-reflection, adaptive learning, and human feedback loops, the system improves itself over time — becoming more accurate, more personal, and more useful with every interaction.',
              },
            ].map((item, i) => (
              <div
                key={i}
                className="feature-animate p-8 border border-[rgba(245,245,240,0.08)]"
                style={{ background: 'rgba(26, 26, 37, 0.6)' }}
              >
                <h3 className="font-display text-xl text-[#F5F5F0] mb-4">{item.title}</h3>
                <p className="text-[13px] text-[#8A8A9A] leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
